<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TDN</title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo1.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guest/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guest/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guest/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guest/banniere.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <?php echo $__env->yieldContent('extra-styles'); ?>
</head>
<body>
    <?php echo $__env->make('guest.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('guest.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('banniere'); ?>
    <?php echo $__env->make('guest.includes.echo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main-container">
        <?php echo $__env->yieldContent("content"); ?>
    </main>
    <?php echo $__env->make('guest.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('assets/scripts/guest/app.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/scripts/guest/navbar.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/scripts/guest/banniere.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tdn\resources\views/guest/layout.blade.php ENDPATH**/ ?>