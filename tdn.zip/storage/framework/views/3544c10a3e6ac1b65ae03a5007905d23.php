<?php $__env->startSection('content'); ?>
    <h1>Bienvenue à TDN</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("guest.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\koffi\Herd\tdn\resources\views/guest/pages/home.blade.php ENDPATH**/ ?>