<?php $__env->startSection('extra-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/styles/guest/pages/news/index.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section class="news-header">
        <h1 class="news-title">Actualités</h1>
        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" name="news-search" id="news-search" class="form-control" placeholder="Rechercher...">
        </form>
    </section>
    <section class="news-subheader">
        <ul class="news-categories">
            <li class="news-category"><a href="#">Santé</a></li>
            <li class="news-category"><a href="#">Commerce</a></li>
            <li class="news-category"><a href="#">Transport</a></li>
            <li class="news-category"><a href="#">Informatique</a></li>
            <li class="news-category"><a href="#">Téléphonies et TV</a></li>
            <li class="news-category"><a href="#">Nettoyage et entretien</a></li>
            <li class="news-category"><a href="#">Urbanisme et construction</a></li>
            <li class="news-category"><a href="#">Secteurs privés</a></li>
        </ul>
    </section>
    <section class="news-grid">
        <?php for($i = 0; $i < 4; $i++): ?>
            <div class="news-grid-item">
                <figure class="news-grid-item-image">
                    <img src="<?php echo e(asset('assets/images/news1.jpg')); ?>" alt="">
                    <div class="news-grid-item-region">Plateau</div>
                </figure>
                <div class="news-grid-item-body">
                    <span class="news-grid-item-published-at">Publié le 24/08/2024</span>
                    <h1 class="news-grid-item-title">L'Arcep inflige une amende de 1,2 milliard FCFA à Moov pour indisponibilité de ses services</h1>
                    <a href="<?php echo e(route('guest.news.show')); ?>" class="news-grid-item-link">Lire plus</a>
                </div>
            </div>
        <?php endfor; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tdn\resources\views/guest/pages/news/index.blade.php ENDPATH**/ ?>