<header>
    <figure class="header-logo">
        <img src="<?php echo e(asset('assets/images/logo1.png')); ?>" alt="">
    </figure>
    <div class="slogan-container">
        <p>Un slogan accrocheur</p>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\tdn\resources\views/guest/includes/header.blade.php ENDPATH**/ ?>