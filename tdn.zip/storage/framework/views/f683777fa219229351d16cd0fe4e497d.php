<section class="echo-container">
    <div class="echo-title">Echo TƉN</div>
    <ul class="echo-content">
        <li class="echo-content-item">
            <span class="echo-content-item-title">Politique: </span>
            <span class="echo-content-item-text">Le chef de l'Etat remercie son homologue rwandais Paul Kagame pour sa réelection.</span>
        </li>
        <li class="echo-content-item">
            <span class="echo-content-item-title">Economie: </span>
            <span class="echo-content-item-text">Le taux de change du franc CFA est monté en flêche</span>
        </li>
        <li class="echo-content-item">
            <span class="echo-content-item-title">Société: </span>
            <span class="echo-content-item-text">Le gouvernement a décidé de créer un lieu social pour arbriter les plus démunis </span>
        </li>
        <li class="echo-content-item">
            <span class="echo-content-item-title">Politique: </span>
            <span class="echo-content-item-text">Le chef de l'Etat remercie son homologue rwandais Paul Kagame pour sa réelection.</span>
        </li>
        <li class="echo-content-item">
            <span class="echo-content-item-title">Economie: </span>
            <span class="echo-content-item-text">Le taux de change du franc CFA est monté en flêche</span>
        </li>
        <li class="echo-content-item">
            <span class="echo-content-item-title">Société: </span>
            <span class="echo-content-item-text">Le gouvernement a décidé de créer un lieu social pour arbriter les plus démunis </span>
        </li>
    </ul>
</section>
<?php /**PATH C:\xampp\htdocs\tdn\resources\views/guest/includes/echo.blade.php ENDPATH**/ ?>