<header>
    <figure class="header-logo">
        <img src="{{ asset('assets/images/logo1.png') }}" alt="">
    </figure>
    <div class="slogan-container">
        <p>Un slogan accrocheur</p>
    </div>
</header>
